from Tkinter import *
from tkFileDialog import askopenfilename
from tkFileDialog import askdirectory
import csv

def infile():
    return askopenfilename()
     
def outfile():
    return askdirectory()
    
def run():
    with open(infile(), 'rb') as csvfile:
        csv_file = csv.reader(csvfile, delimiter=',')
        csv_file = list(csv_file)

        new_csv = [['Temperature']]

        for i in range(1,len(csv_file)): #creates temperature column
            new_csv.append([csv_file[i][3]])
            if(csv_file[i+1][1] != csv_file[i][1]):
                break
        k = 0
        i = 0
        while (k < 96): #fills column names
            if(csv_file[i][1] != csv_file[i+1][1]):
                new_csv[0].append(csv_file[i+1][1])
                k = k+1
                i = i+1
            else:
                i = i+1

        j = 1
        k = 0
        i = 1 
        while (k < 96): #puts fluorescence in right spot
            new_csv[j].append(float(csv_file[i][4].replace(',','')))
            if(i % (len(new_csv)-1) == 0):
                j = 1
                k = k+1
                i = i+1
            else:
                j = j+1
                i = i+1

    with open(outfile() + '\\' + 'cleaned_tsa.csv', "wb") as x:
        output = csv.writer(x)
        output.writerows(new_csv)

errmsg = 'Error! Call Kyle, or the ghostbusters.'

#Button(text='File To Be Parsed', command=infile).pack(fill=X)
#Button(text='Output Directory', command=outfile).pack(fill=X)
Button(text='Parse TSA Data from QS3 Instrument \n (Click me)', command=run).pack(fill='both', ipadx=20, ipady=20)

mainloop()
